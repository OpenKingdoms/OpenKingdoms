OK Registry Test 1.0

A test mod for the OpenKingdoms mod registry. It adds one feature that
no map places, so it changes the game data fingerprint and nothing else.
Installing it from the registry puts the Mods folder below into your game
folder. This file is not installed.
